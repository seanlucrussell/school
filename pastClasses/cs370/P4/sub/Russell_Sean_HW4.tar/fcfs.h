#ifndef FCFS
#define FCFS

#include <stdlib.h>
#include <stdio.h>
#include "util.h"

void firstComeFirstServed();

#endif
