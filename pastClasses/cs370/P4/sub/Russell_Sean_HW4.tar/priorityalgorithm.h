#ifndef priorityalgorithm
#define priorityalgorithm

#include <stdlib.h>
#include <stdio.h>
#include "util.h"

void priorityAlgorithm();

#endif
