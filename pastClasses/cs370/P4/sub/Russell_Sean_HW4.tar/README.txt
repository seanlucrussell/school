Run the program by typing "./P4 input_file_name random_number_seed".
After this, the program will prompt you for an algorithm until "exit" is typed into the console.
The options for the program are case sensitive, so be careful of this.
