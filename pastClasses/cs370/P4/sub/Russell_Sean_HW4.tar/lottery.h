#ifndef lotteryheader
#define lotteryheader

#include <stdlib.h>
#include <stdio.h>
#include "util.h"

void lottery(int seed);

#endif
