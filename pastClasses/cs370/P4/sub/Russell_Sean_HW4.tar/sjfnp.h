#ifndef SJFNP
#define SJFNP

#include <stdlib.h>
#include <stdio.h>
#include "util.h"

void shortestJobFirstNonPreemptive();

#endif
