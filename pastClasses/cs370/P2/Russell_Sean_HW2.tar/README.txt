type *make* to compile
type *make clean* to clean up files
type *./coorinator a b c d e* with int values substituted for a b c d e to run program
