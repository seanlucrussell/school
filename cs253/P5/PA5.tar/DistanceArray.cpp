#include <DistanceArray.h>

void DistanceArray::poseSequenceCompare(const PoseSequence& a, const PoseSequence& b) {
  for (size_t i=0, maxa=a.size();i<maxa;i++){
    vector<double> temp;
    for (size_t j=0, maxb=b.size();j<maxb;j++){
      temp.push_back(a.getPose(i).poseCompare(b.getPose(j)));
    }
    distances.push_back(temp);
  }
}

void DistanceArray::printArray() const {
  for (size_t i = 0; i < distances.size(); i++){
    for (size_t j = 0; j < distances[i].size(); j++)
        cout << std::fixed << std::setprecision(8) << distances[i][j] << " ";
    cout << endl;
  }
}

void DistanceArray::dynamicTimeWarping() {
  vector< vector<double> > w;
  w.push_back(distances[0]);

  for (size_t i=1;i<distances.size();i++){
    vector<double> temp;
    for (size_t j=0;j<distances[i].size();j++){
      double smallest = distances[i-1][0];
      for (size_t k=1;k<j;k++){
        if (distances[i-1][k]<smallest)
          smallest = distances[i-1][k];
      }
      temp.push_back(smallest);
    }
    w.push_back(temp);
  }
  
  double smallest = w[w.size()-1][0];
  for (size_t i=0;i<w[0].size();i++)
    if(w[w.size()-1][i]<smallest)
      smallest = w[w.size()-1][i];
  cout << std::setprecision(8) << smallest << endl;
}
