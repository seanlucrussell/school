#ifndef DISTANCEARRAY_H
#define DISTANCEARRAY_H

#include <vector>
#include <iostream>

#include <Pose.h>
#include <PoseSequence.h>
#include <iomanip>

class DistanceArray{
 public:
  void poseSequenceCompare(const PoseSequence& a, const PoseSequence& b);
  void printArray() const;
  void dynamicTimeWarping();
 protected:
  vector< vector <double> > distances;
};

#endif
