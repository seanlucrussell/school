#ifndef DISTANCE_H
#define DISTANCE_H

#include <Pose.h>
#include <vector>
#include <algorithm>

class Distance{
 public:
  virtual double poseDistance(const Pose& a, const Pose& b);
};

class MedianDistance: public Distance{
 public:
  virtual double poseDistance(const Pose& a, const Pose& b);
};

class AverageDistance: public Distance{
 public:
  virtual double poseDistance(const Pose& a, const Pose& b);
};

class MaxDistance: public Distance{
 public:
  virtual double poseDistance(const Pose& a, const Pose& b);
};

class EuclidianDistance: public Distance{
 public:
  virtual double poseDistance(const Pose& a, const Pose& b);
};


#endif
