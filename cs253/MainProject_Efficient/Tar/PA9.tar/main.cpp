#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#include <PoseSequence.h>
#include <DistanceArray.h>
#include <Distance.h>

using std::cout;
using std::endl;
using std::cerr;
using std::fstream;

void usage() {
  cout << "Usage: pa1 filename" << endl;
}

/// Prints error to console
/// @param error: string holding error message
/// @return returns -1
int error(const char* error){
  cerr << "Error: " << error << endl;
  usage();
  return -1;
}

int main(int argc, char* argv[]){
  // Check for correct number of arguments
  if (argc != 2)
    return error("incorrect number of arguments");
  // Check long sequence
  PoseSequence seq;
  if (seq.readFromName(argv[1])==-1)
    return error("failed to read sequence");
  if (seq.size() < 60)
    return error("video too short");
  // Select distance type to use
  EuclidianDistance dist;

  DistanceArray d;
//  d.poseSequenceCompare(shortPoses[0],sequenceLong,*dist);
/*
  int smallestIndex = 0;
  double smallest = d.dynamicTimeWarping();
  for(size_t i=0;i<shortPoses.size();i++) {
    DistanceArray d;
    d.poseSequenceCompare(shortPoses[i],sequenceLong,*dist);
    double dtw = d.dynamicTimeWarping();
    if(dtw < smallest){
      smallest = dtw;
      smallestIndex = i;
    }
  }
  cout << argv[smallestIndex + 2] << endl;
*/

  double minimumTimeWarping = d.poseSequenceCompare(seq.subSequence(0,30),seq.subSequence(30,seq.size()),dist) / 30;
  int minimumPoseSize = 30;

  for(int i=31;i<=seq.size()/2;i++) {
    double distance = d.poseSequenceCompare(seq.subSequence(0,i),seq.subSequence(i,seq.size()),dist) / i;
    if (distance < minimumTimeWarping){
      minimumTimeWarping = distance;
      minimumPoseSize = i;
    }
  }
  cout << minimumPoseSize << endl;

  // For all i from 30 to (length/2).floor
  // Make 2 subsets of long sequence
  //  one from 0 to i
  //  one from i+1 to length
  // get a distance DistanceArray.poseSequenceCompare(short,long,dist) / length of small
  // compare to lowest value
  // if lower, keep in thing
  
  return 0;
}
